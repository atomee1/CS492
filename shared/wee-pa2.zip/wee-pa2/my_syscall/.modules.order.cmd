cmd_kernel/my_syscall/modules.order := {  :; } > kernel/my_syscall/modules.order
