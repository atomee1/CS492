cmd_kernel/my_syscall/built-in.a := rm -f kernel/my_syscall/built-in.a;  printf "kernel/my_syscall/%s " my_syscall.o | xargs ar cDPrST kernel/my_syscall/built-in.a
