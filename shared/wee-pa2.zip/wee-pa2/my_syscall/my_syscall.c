#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h>

SYSCALL_DEFINE1(wee_syscall, char __user *, user_str)
{
    char kbuf[33];
    int i, count = 0;

    if (!user_str) return -1;

    if (strncpy_from_user(kbuf, user_str, sizeof(kbuf)) < 0)
        return -1;

    kbuf[32] = '\0';

    printk(KERN_INFO "before: %s\n", kbuf);

    for (i = 0; kbuf[i] != '\0'; i++) {
        if (strchr("aeiouyAEIOUY", kbuf[i])) {
            kbuf[i] = 'J';
            count++;
        }
    }

    printk(KERN_INFO "after: %s\n", kbuf);

    if (copy_to_user(user_str, kbuf, strlen(kbuf) + 1))
        return -1;

    return count;
}
