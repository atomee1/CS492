cmd_/home/wee/wee-pa2/module/wee.mod := printf '%s\n'   wee.o | awk '!x[$$0]++ { print("/home/wee/wee-pa2/module/"$$0) }' > /home/wee/wee-pa2/module/wee.mod
