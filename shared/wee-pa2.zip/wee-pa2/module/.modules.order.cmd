cmd_/home/wee/wee-pa2/module/modules.order := {   echo /home/wee/wee-pa2/module/wee.ko; :; } > /home/wee/wee-pa2/module/modules.order
