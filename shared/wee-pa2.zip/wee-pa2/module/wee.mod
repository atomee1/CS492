/home/wee/wee-pa2/module/wee.o
