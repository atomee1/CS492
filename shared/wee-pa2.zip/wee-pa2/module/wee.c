#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("William Ee");
MODULE_DESCRIPTION("Linux Kernel Module");

static int __init wee_init(void)
{
    printk(KERN_INFO "Hello World from William Ee (wee)\n");
    return 0;
}

static void __exit wee_exit(void)
{
    printk(KERN_INFO "PID is %d and program name is %s\n", current->pid, current->comm);
}

module_init(wee_init);
module_exit(wee_exit);
