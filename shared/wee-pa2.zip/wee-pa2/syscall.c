#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>

#define SYS_wee_syscall 451

int main() {
    char test1[] = "shorter string";
    char test2[] = "very veeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeery long string";

    printf("Before syscall: %s\n", test1);
    long result = syscall(SYS_wee_syscall, test1);
    printf("Syscall returned: %ld\n", result);
    printf("After syscall: %s\n\n", test1);

    printf("Before syscall: %s\n", test2);
    result = syscall(SYS_wee_syscall, test2);
    printf("Syscall returned: %ld\n", result);
    printf("After syscall: %s\n", test2);

    return 0;
}
